package com.example.dundy.supermarket;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

class ActivitiyHome extends AppCompatActivity {

    public static final String PREFS_NAME = "LoginPrefs";
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);


        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        if (settings.getString("logged", "").toString().equals("logged")) {
            Intent intent = new Intent(ActivitiyHome.this, MainActivity.class);
            startActivity(intent);
        }

        Button b = (Button) findViewById(R.id.loginbutton);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText username = (EditText) findViewById(R.id.login);
                EditText password = (EditText) findViewById(R.id.password);


                if(username.getText().toString().equals("star") && password.getText().toString().equals("store"))                     {
                    //make SharedPreferences object
                    SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
                    SharedPreferences.Editor editor = settings.edit();
                    editor.putString("logged", "logged");
                    editor.commit();
                    Toast.makeText(getApplicationContext(), "Successfull Login", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(ActivitiyHome.this,MainActivity.class);
                    startActivity(intent);
                }

            }
        });
    }
}